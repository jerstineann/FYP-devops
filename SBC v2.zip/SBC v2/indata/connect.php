<?php 
	$con=mysqli_connect('localhost','root','','sbc');
	if(!$con){
		die(mysqli_error($con));
	}
 ?>